import tkinter as tk
from tkinter import ttk, messagebox
from PIL import Image, ImageTk  # ✅ Import for background image
from project.auth import capture_face, match_face

# --------------------- Setup ---------------------
root = tk.Tk()
root.title("🔐 Face Recognition Auth System")
root.geometry("500x350")
root.resizable(False, False)

# Load and place background image as watermark
bg_image = Image.open("watermark.png").resize((500, 350), Image.Resampling.LANCZOS
)
bg_photo = ImageTk.PhotoImage(bg_image)

bg_label = tk.Label(root, image=bg_photo)
bg_label.place(x=0, y=0, relwidth=1, relheight=1)

# Allowed usernames
ALLOWED_USERS = ["anshika", "tanishq"]

def is_allowed(name):
    return name.lower() in ALLOWED_USERS

def register():
    name = username_entry.get().strip().lower()
    if not is_allowed(name):
        messagebox.showerror("Access Denied", "Only Anshika and Tanishq are allowed to register.")
        return
    capture_face(name)

def login():
    name = username_entry.get().strip().lower()
    if not is_allowed(name):
        messagebox.showerror("Access Denied", "Only Anshika and Tanishq are allowed to login.")
        return
    match_face(name)

# --------------------- Custom Styles ---------------------
style = ttk.Style()
style.theme_use("default")

style.configure("TButton",
    font=("Segoe UI", 12, "bold"),
    padding=10,
    background="#008CBA",
    foreground="white",
    borderwidth=0)
style.map("TButton", background=[("active", "#0056b3")])



# Username
username_label = tk.Label(root, text="Enter username:", font=("Segoe UI", 12),
                          bg="#e8f0fe", fg="#050505")
username_label.place(x=160, y=80)

username_entry = ttk.Entry(root, font=("Segoe UI", 12), width=30)
username_entry.place(x=110, y=110)
username_entry.configure(foreground="#000", background="#ffffff")


# Buttons
register_btn = ttk.Button(root, text="📷 Register Face", command=register)
register_btn.place(x=100, y=170)

login_btn = ttk.Button(root, text="✅ Login with Face", command=login)
login_btn.place(x=270, y=170)

# Footer
footer = tk.Label(root, text="© 2025 | Secured by Anshika/Tanishq", font=("Segoe UI", 9),
                  bg="#e8f0fe", fg="#555")
footer.place(x=160, y=310)

root.mainloop()
