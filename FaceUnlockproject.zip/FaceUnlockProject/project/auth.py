import cv2
import os
import tkinter.messagebox
import tkinter.simpledialog
from datetime import datetime
from project.config import FACE_DATA_DIR, FILE_TO_OPEN, MAX_ATTEMPTS
from project.utils import is_locked, activate_lock, clear_lock


def capture_face(username):
    user_face_path = os.path.join(FACE_DATA_DIR, f"{username}.jpg")

    if os.path.exists(user_face_path):
        cam = cv2.VideoCapture(0)
        if not cam.isOpened():
            tkinter.messagebox.showerror("Camera Error", "Webcam not accessible.")
            return

        stored_image = cv2.imread(user_face_path, cv2.IMREAD_GRAYSCALE)
        matched = False
        attempts = 0

        tkinter.messagebox.showinfo("Verify", f"{username.capitalize()}, please verify your identity to update your face.")

        while attempts < 3:
            ret, frame = cam.read()
            if not ret:
                break

            gray_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            diff = cv2.absdiff(stored_image, gray_frame)
            score = cv2.mean(diff)[0]

            cv2.imshow("Identity Check", frame)
            k = cv2.waitKey(1)
            if k % 256 == 32:  # SPACE
                if score < 60:  # less strict
                    matched = True
                    break
                else:
                    attempts += 1
                    tkinter.messagebox.showwarning("Mismatch", f"Face did not match. Attempts left: {3 - attempts}")
            elif k % 256 == 27:  # ESC
                break

        cam.release()
        cv2.destroyAllWindows()

        if not matched:
            tkinter.messagebox.showerror("Access Denied", "You're not the original user.\nFace re-registration blocked.")
            return

        tkinter.messagebox.showinfo("Verified", "Face matched. You may now update your face.")

    # Register or overwrite face
    cam = cv2.VideoCapture(0)
    if not cam.isOpened():
        tkinter.messagebox.showerror("Camera Error", "Webcam not accessible.")
        return

    cv2.namedWindow("Register Face")

    while True:
        ret, frame = cam.read()
        if not ret:
            break

        cv2.imshow("Register Face", frame)
        k = cv2.waitKey(1)
        if k % 256 == 27:  # ESC
            break
        elif k % 256 == 32:  # SPACE
            cv2.imwrite(user_face_path, frame)
            tkinter.messagebox.showinfo("Success", f"Face registered/updated for {username.capitalize()}")
            break

    cam.release()
    cv2.destroyAllWindows()


def match_face(username):
    if is_locked():
        tkinter.messagebox.showerror("Access Denied", "Too many failed attempts.\nAccess locked for 24 hours.")
        return

    user_face_path = os.path.join(FACE_DATA_DIR, f"{username}.jpg")
    if not os.path.exists(user_face_path):
        tkinter.messagebox.showerror("Not Found", "No face registered for this username.")
        return

    stored_image = cv2.imread(user_face_path, cv2.IMREAD_GRAYSCALE)
    cam = cv2.VideoCapture(0)
    if not cam.isOpened():
        tkinter.messagebox.showerror("Camera Error", "Webcam not accessible.")
        return

    attempt = 0
    matched = False

    while attempt < MAX_ATTEMPTS:
        ret, frame = cam.read()
        if not ret:
            break

        gray_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        diff = cv2.absdiff(stored_image, gray_frame)
        score = cv2.mean(diff)[0]

        cv2.imshow("Login Face Match", frame)
        k = cv2.waitKey(1)
        if k % 256 == 32:  # SPACE
            if score < 60:
                matched = True
                break
            else:
                attempt += 1
                tkinter.messagebox.showwarning("Mismatch", f"Face did not match. Attempts left: {MAX_ATTEMPTS - attempt}")
        elif k % 256 == 27:
            break

    cam.release()
    cv2.destroyAllWindows()

    if matched:
        clear_lock()
        welcome_name = username.capitalize()
        tkinter.messagebox.showinfo("Welcome", f"Welcome {welcome_name}!\nAccess Granted ✅")
        os.startfile(FILE_TO_OPEN)
    else:
        activate_lock()
        tkinter.messagebox.showerror("Access Denied", "Failed 3 times. File is now locked for 24 hours.")
