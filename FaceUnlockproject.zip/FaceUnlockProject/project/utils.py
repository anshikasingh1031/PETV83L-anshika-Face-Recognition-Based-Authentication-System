import os
from datetime import datetime, timedelta
from project.config import LOCK_FILE, LOCKOUT_DURATION

def is_locked():
    if not os.path.exists(LOCK_FILE):
        return False
    with open(LOCK_FILE, "r") as f:
        content = f.read().strip()
    if not content:
        return False
    lock_time = datetime.strptime(content, "%Y-%m-%d %H:%M:%S")
    if datetime.now() - lock_time < timedelta(hours=LOCKOUT_DURATION):
        return True
    else:
        os.remove(LOCK_FILE)
        return False

def activate_lock():
    with open(LOCK_FILE, "w") as f:
        f.write(datetime.now().strftime("%Y-%m-%d %H:%M:%S"))

def clear_lock():
    if os.path.exists(LOCK_FILE):
        os.remove(LOCK_FILE)
