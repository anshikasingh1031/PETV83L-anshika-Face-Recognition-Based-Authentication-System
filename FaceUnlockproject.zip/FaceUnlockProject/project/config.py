ALLOWED_USERS = ["Anshika", "Tanishq"]

# Folder where face images are saved
FACE_DATA_DIR = "project/user_faces"

# Path to the protected file
FILE_TO_OPEN = "private.txt"

# Locking mechanism
LOCK_FILE = "project/login_lock.txt"
MAX_ATTEMPTS = 3
LOCKOUT_DURATION = 24
